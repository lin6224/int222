        function calcFactorial()
         {
            //newWin= window.open("", "newWin", "width=400,height=200");
            //newWin.document.write("Heee");
           
           var temp=window.document.frm.factN.value;
	                var x = parseInt(temp);
	                if (x==temp && x>=0)
	                  {
	                    newWin= window.open("", "newWin", "width=400,height=200");
	                    newWin.document.write("factorial for "+ x + " is: "+ factorial(x) +"<br />");
	                    newWin.moveTo(400,0);
	                    newWin.focus();
	                   }
	                else
	                  {
	                    alert("Reinput a non-negative integer.");
               }
         }

         function factorial(n)
         {
             var i=1;
             var f =1;
            /* if (n=0)
             {
                f=1;
             } */
             for (i=1; i<=n; i++)
             {
                f= f*i;
             }
           return f;
         }

       function pracString()
       {
          var s="This is a hard test!" ;
          win2 = window.open("", "win2", "width=400,height=200");
          win2.document.write("length: "+s.length+"<br/>");
          win2.document.write("get hard: "+s.substr(10, 4)+"<br/>");
          win2.document.write("position is (not is in This): "+s.lastIndexOf("is")+"<br/>");
          win2.document.write("Done! <br/>");
          win2.moveTo(400, 400);
          win2.focus();
          
       }