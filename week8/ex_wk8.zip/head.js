     		   function message()
    		   {
        		   alert("This javaScript is in external file and was called with the onload event");
    		   }